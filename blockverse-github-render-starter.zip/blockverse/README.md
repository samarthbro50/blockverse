# Blockverse — Roblox-inspired creator platform starter

Blockverse is an **independent browser game-creation platform prototype**, not Roblox and not affiliated with Roblox Corporation.

## What this starter includes
- Account registration and login (bcrypt password hashing + JWT).
- Discover page for published games.
- A simple 3D block-world editor (add/remove blocks, change block color, title/description).
- Save drafts and publish/unpublish games.
- Play published block worlds in a Three.js viewer.
- PostgreSQL persistence and a Render Blueprint.

## Important scope notes
This is a first MVP, not a full Roblox replacement. It does **not** yet include 30-player realtime multiplayer, scripting/sandboxing, avatar inventory, chat, moderation dashboards, payments, or user-uploaded executable code. The 30-player target is a future per-game server capacity goal; do not advertise it as live until authoritative multiplayer servers and load tests are added.

The editor currently publishes safe scene data (JSON blocks), not arbitrary scripts. Keep it that way until a hardened, sandboxed runtime exists.

## Run locally
Requirements: Node.js 20+ and PostgreSQL.

1. Create a PostgreSQL database.
2. Copy `server/.env.example` to `server/.env` and set `DATABASE_URL` and `JWT_SECRET`.
3. From the project root:
   ```bash
   npm install
   npm install --prefix server
   npm install --prefix client
   npm run dev
   ```
4. Open http://localhost:5173

The API runs on http://localhost:4000. Tables are created automatically on server start.

## Deploy with GitHub + Render
1. Create a GitHub repository named `blockverse`.
2. Upload/push this project to the repository.
3. In Render, choose **New → Blueprint**, connect the repository, and let Render read `render.yaml`.
4. Render creates the web service and PostgreSQL database. The Blueprint sets `JWT_SECRET` automatically.
5. After deployment, open the Render URL and register an account.

If you change the database plan in `render.yaml`, choose a plan available in your Render account. Render plan names/prices can change.

## Architecture
- `client/`: Vite + vanilla JavaScript + Three.js.
- `server/`: Express REST API, JWT auth, PostgreSQL.
- `render.yaml`: Render Blueprint.

## Before inviting friends
Add email verification, password reset, rate limiting, report/block tools, moderation, backups, privacy policy, terms, and abuse monitoring. For multiplayer, add WebSocket rooms with server-authoritative movement, strict room capacity (max 30), reconnect handling, and load tests. Never trust client-reported positions or scores.
