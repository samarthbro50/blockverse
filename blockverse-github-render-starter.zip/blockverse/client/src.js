import * as THREE from 'three';
import './style.css';

const API = '/api';
const app = document.querySelector('#app');
let token = localStorage.getItem('bv_token') || '';
let user = null, myGames = [], publicGames = [], activeGame = null, sceneData = { blocks: [] };
let renderer, worldScene, camera, frameId;
const $ = (s) => document.querySelector(s);
const esc = (s='') => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path, opts={}) {
  const res = await fetch(API+path, { ...opts, headers: { 'Content-Type':'application/json', ...(token?{Authorization:`Bearer ${token}`} : {}), ...(opts.headers||{}) }});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function shell() {
 app.innerHTML = `<header class="top"><a class="brand" href="#" data-page="home"><span class="brand-mark">▦</span> BLOCKVERSE</a>
 <nav><button data-page="discover">Discover</button><button data-page="create">Create</button><button data-page="library">My games</button></nav>
 <div class="account">${user?`<span class="muted">Hey, ${esc(user.username)}</span><button class="btn ghost" id="logout">Log out</button>`:`<button class="btn ghost" id="login-open">Log in</button><button class="btn primary" id="signup-open">Sign up</button>`}</div></header><main id="view"></main>
 <footer>BLOCKVERSE <span>Made for friends · Build something awesome.</span></footer>`;
 $('#logout')?.addEventListener('click',()=>{token='';user=null;localStorage.removeItem('bv_token');render('home')});
 $('#login-open')?.addEventListener('click',()=>authModal('login'));
 $('#signup-open')?.addEventListener('click',()=>authModal('register'));
}
function authModal(mode) {
 const overlay=document.createElement('div'); overlay.className='overlay';
 overlay.innerHTML=`<form class="modal" id="auth-form"><button type="button" class="close" aria-label="Close">×</button><div class="eyebrow">JOIN THE UNIVERSE</div><h2>${mode==='login'?'Welcome back':'Create your account'}</h2><label>Username<input name="username" minlength="3" maxlength="24" required autocomplete="username"></label><label>Password<input name="password" type="password" minlength="8" required autocomplete="${mode==='login'?'current-password':'new-password'}"></label><button class="btn primary full">${mode==='login'?'Log in':'Create account'}</button><p class="muted" id="auth-error"></p><p class="muted center">${mode==='login'?'New here?':'Already have an account?'} <a href="#" id="switch-auth">${mode==='login'?'Sign up':'Log in'}</a></p></form>`;
 document.body.append(overlay); overlay.querySelector('.close').onclick=()=>overlay.remove();
 overlay.querySelector('#switch-auth').onclick=e=>{e.preventDefault();overlay.remove();authModal(mode==='login'?'register':'login')};
 overlay.querySelector('form').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{const d=await api('/'+mode,{method:'POST',body:JSON.stringify({username:f.get('username'),password:f.get('password')})});token=d.token;user=d.user;localStorage.setItem('bv_token',token);overlay.remove();render('home')}catch(err){overlay.querySelector('#auth-error').textContent=err.message}};
}
async function load() {
 try { if(token) { const d=await api('/me'); user=d.user; myGames=(await api('/my/games')).games; } }
 catch { token='';user=null;localStorage.removeItem('bv_token'); }
 try { publicGames=(await api('/games')).games; } catch {}
}
function gameCard(g) { return `<article class="game-card"><div class="thumb"><div class="mini-world">${Array.from({length:9},(_,i)=>`<i style="--i:${i};--c:${esc(g.scene?.blocks?.[i]?.color||['#8b7cff','#42d6bd','#ffb65e'][i%3])}"></i>`).join('')}</div><span class="tag">WORLD</span></div><div class="game-info"><div><h3>${esc(g.title)}</h3><p>by ${esc(g.owner||user?.username||'Creator')}</p></div><button class="btn small primary" data-play="${g.id}">Play →</button></div></article>`; }
async function render(page='home') {
 cancelAnimationFrame(frameId); shell(); await load(); shell();
 const view=$('#view');
 if(page==='home'||page==='discover') {
  view.innerHTML=`<section class="hero"><div class="hero-copy"><div class="eyebrow"><span class="dot"></span> YOUR FRIENDS. YOUR WORLDS.</div><h1>Play worlds.<br><em>Create legends.</em></h1><p>A place where anyone can build a little world, publish it, and invite friends to play.</p><div class="actions"><button class="btn primary big" id="hero-create">＋ Start creating</button><button class="btn ghost big" data-page="discover">Explore games ↗</button></div><div class="hero-stats"><span><b>${publicGames.length}</b> community worlds</span><span><b>∞</b> ideas to build</span></div></div><div class="hero-art"><div class="orbit o1"></div><div class="orbit o2"></div><div class="float-block b1"></div><div class="float-block b2"></div><div class="float-block b3"></div><div class="island"><div class="tree">♣</div><div class="avatar">●</div></div><div class="spark s1">✦</div><div class="spark s2">✧</div></div></section>
  <section class="section"><div class="section-head"><div><div class="eyebrow">THE COMMUNITY</div><h2>Worlds to jump into</h2></div><button class="text-btn" data-page="discover">See all ↗</button></div><div class="cards">${publicGames.length?publicGames.slice(0,6).map(gameCard).join(''):`<div class="empty"><div class="empty-icon">▧</div><h3>It's quiet out here… for now.</h3><p>Be the first to publish a world for your friends.</p><button class="btn primary" id="empty-create">Create the first world</button></div>`}</div></section>`;
  $('#hero-create').onclick=()=>render('create'); $('#empty-create')?.addEventListener('click',()=>render('create'));
 } else if(page==='create') {
  if(!user){view.innerHTML=`<section class="center-stage"><div class="eyebrow">CREATOR STUDIO</div><h1>Your next world starts here.</h1><p>Sign in to create and publish your own block worlds.</p><button class="btn primary big" id="need-auth">Create free account</button></section>`;$('#need-auth').onclick=()=>authModal('register');return;}
  activeGame=null;sceneData={blocks:[{x:0,y:0,z:0,color:'#8b7cff'},{x:1,y:0,z:0,color:'#42d6bd'},{x:0,y:0,z:1,color:'#ffb65e'}]};
  view.innerHTML=editorMarkup(); setupEditor();
 } else if(page==='library') {
  view.innerHTML=`<section class="section page-section"><div class="section-head"><div><div class="eyebrow">CREATOR STUDIO</div><h1>My worlds</h1><p class="muted">Your drafts and published creations.</p></div><button class="btn primary" id="new-world">＋ New world</button></div><div class="cards">${myGames.length?myGames.map(g=>`<article class="game-card"><div class="thumb"><div class="mini-world">${(g.scene?.blocks||[]).slice(0,9).map((b,i)=>`<i style="--i:${i};--c:${b.color}"></i>`).join('')}</div><span class="tag">${g.published?'PUBLISHED':'DRAFT'}</span></div><div class="game-info"><div><h3>${esc(g.title)}</h3><p>${g.published?'Visible to everyone':'Only you can see this'}</p></div><button class="btn small" data-edit="${g.id}">Edit</button></div></article>`).join(''):`<div class="empty"><h3>No worlds yet</h3><p>Make your first world and share it with friends.</p></div>`}</div></section>`;
  $('#new-world').onclick=()=>render('create');
  view.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEditor(b.dataset.edit));
 } else if(page==='play' && activeGame) {
  view.innerHTML=`<section class="play-head"><div><div class="eyebrow">NOW PLAYING</div><h1>${esc(activeGame.title)}</h1><p>${esc(activeGame.description)}</p></div><button class="btn ghost" id="back-discover">← Back to worlds</button></section><div class="game-stage"><div id="game-canvas"></div><div class="controls-hint">WASD / Arrow keys to move camera · Drag to orbit · Scroll to zoom</div></div>`;
  $('#back-discover').onclick=()=>render('discover'); mountWorld($('#game-canvas'),activeGame.scene);
 }
 view.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>render(b.dataset.page)));
 view.querySelectorAll('[data-play]').forEach(b=>b.addEventListener('click',()=>playGame(b.dataset.play)));
}
function editorMarkup(){return `<section class="editor-page"><div class="editor-top"><div><div class="eyebrow">CREATOR STUDIO / NEW WORLD</div><h1>Build your world</h1></div><div class="editor-actions"><button class="btn ghost" id="save-draft">Save draft</button><button class="btn primary" id="publish">Publish world ↗</button></div></div><div class="editor-layout"><aside class="tool-panel"><h3>World settings</h3><label>World name<input id="world-title" maxlength="48" value="${esc(activeGame?.title||'My awesome world')}"></label><label>Description<textarea id="world-desc" maxlength="240" rows="3" placeholder="What's your world about?">${esc(activeGame?.description||'')}</textarea></label><div class="rule"></div><h3>Build tools</h3><button class="tool active" id="add-block">＋ Add block</button><button class="tool" id="remove-block">− Remove last block</button><label>Block color<input id="block-color" type="color" value="#8b7cff"></label><div class="tip">Tip: Add blocks to make platforms, towers, and little places to explore.</div><div id="editor-status" class="status"></div></aside><div class="editor-view"><div class="view-label">3D BUILD VIEW <span>● LIVE PREVIEW</span></div><div id="editor-canvas"></div><div class="canvas-help">Drag to orbit · Scroll to zoom · Build with the tools</div></div></div></section>`;}
function setupEditor(){mountWorld($('#editor-canvas'),sceneData,true);
 $('#add-block').onclick=()=>{if(sceneData.blocks.length>=250)return status('Maximum 250 blocks reached.');const n=sceneData.blocks.length;sceneData.blocks.push({x:(n%7)-3,y:0,z:Math.floor(n/7)-3,color:$('#block-color').value});refreshWorld();};
 $('#remove-block').onclick=()=>{sceneData.blocks.pop();refreshWorld();};
 $('#block-color').oninput=()=>$('#add-block').classList.add('active');
 $('#save-draft').onclick=()=>saveWorld(false);$('#publish').onclick=()=>saveWorld(true);
}
function status(msg){$('#editor-status').textContent=msg;}
async function saveWorld(published){
 try {
  const payload={title:$('#world-title').value,description:$('#world-desc').value,scene:sceneData,published};
  let d;
  if(activeGame) d=await api('/games/'+activeGame.id,{method:'PUT',body:JSON.stringify(payload)});
  else {d=await api('/games',{method:'POST',body:JSON.stringify(payload)});activeGame=d.game;}
  if(published && !activeGame.published){d=await api('/games/'+activeGame.id,{method:'PUT',body:JSON.stringify(payload)});activeGame=d.game;}
  status(published?'Published! Your world is now in Discover.':'Draft saved.');
  await load();
 } catch(e){status(e.message);}
}
async function openEditor(id){
 try{const d=await api('/games/'+id);activeGame=d.game;sceneData=structuredClone(d.game.scene);const view=$('#view');view.innerHTML=editorMarkup();setupEditor();$('#world-title').value=activeGame.title;$('#world-desc').value=activeGame.description;}
 catch(e){alert(e.message);}
}
async function playGame(id){try{const d=await api('/games/'+id);activeGame=d.game;await render('play');}catch(e){alert(e.message)}}
function mountWorld(el,data,editor=false){
 if(!el)return; const w=el.clientWidth||800,h=el.clientHeight||500;
 worldScene=new THREE.Scene();worldScene.background=new THREE.Color('#111629');
 worldScene.fog=new THREE.Fog('#111629',22,65);
 camera=new THREE.PerspectiveCamera(55,w/h,.1,100);camera.position.set(9,9,12);
 renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(w,h);renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;el.innerHTML='';el.appendChild(renderer.domElement);
 worldScene.add(new THREE.HemisphereLight(0xbacbff,0x28213d,2));
 const light=new THREE.DirectionalLight(0xffffff,2.3);light.position.set(8,14,6);light.castShadow=true;worldScene.add(light);
 const floor=new THREE.Mesh(new THREE.BoxGeometry(18,.5,18),new THREE.MeshStandardMaterial({color:'#252b45',roughness:.85}));floor.position.y=-.5;floor.receiveShadow=true;worldScene.add(floor);
 const grid=new THREE.GridHelper(18,18,'#59618b','#343b5d');grid.position.y=-.23;worldScene.add(grid);
 const geo=new THREE.BoxGeometry(.96,.96,.96);
 (data?.blocks||[]).forEach(b=>{const mesh=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:b.color||'#8b7cff',roughness:.65}));mesh.position.set(b.x,b.y+.5,b.z);mesh.castShadow=true;mesh.receiveShadow=true;worldScene.add(mesh);});
 // Minimal orbit controls without an extra dependency.
 let down=false,lastX=0,lastY=0,theta=Math.PI/4,phi=.9,radius=16;
 const update=()=>{camera.position.set(radius*Math.sin(phi)*Math.cos(theta),radius*Math.cos(phi),radius*Math.sin(phi)*Math.sin(theta));camera.lookAt(0,1,0);};
 update();
 renderer.domElement.addEventListener('pointerdown',e=>{down=true;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture(e.pointerId)});
 renderer.domElement.addEventListener('pointerup',()=>down=false);
 renderer.domElement.addEventListener('pointermove',e=>{if(!down)return;theta-=(e.clientX-lastX)*.008;phi=Math.max(.2,Math.min(1.45,phi+(e.clientY-lastY)*.008));lastX=e.clientX;lastY=e.clientY;update()});
 renderer.domElement.addEventListener('wheel',e=>{radius=Math.max(7,Math.min(28,radius+e.deltaY*.018));update()},{passive:true});
 const animate=()=>{frameId=requestAnimationFrame(animate);renderer.render(worldScene,camera)};animate();
 const resize=new ResizeObserver(()=>{if(!el.isConnected)return;const nw=el.clientWidth,nh=el.clientHeight;if(!nw||!nh)return;camera.aspect=nw/nh;camera.updateProjectionMatrix();renderer.setSize(nw,nh)});resize.observe(el);
}
function refreshWorld(){const el=$('#editor-canvas');mountWorld(el,sceneData,true);}
render('home');
